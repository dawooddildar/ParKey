# ParKey

Live parking-slot app for malls, hospitals and other commercial centers.

- Live grid of 50 slots per lot (A1–E10): green = Free, red = Occupied
- Driver taps a free slot; it turns red, and turns green again when they leave
- 5-minute hold: a selected slot is reserved for the driver; if they don’t confirm parking it is released. One slot per driver at a time.
- Driver marks "I’ve left the lot" to free the slot (manual for now)
- Live counter, e.g. "12/50 slots remaining"; full lots tell drivers to go elsewhere

## Files
- `index.html`: the app (email sign-in, lots and slots loaded from Supabase, live updates)
- `supabase/schema.sql`: tables, security rules, the five lots and 250 slots, realtime, cron job
- `supabase/functions.sql`: `book_slot`, `confirm_parking`, `release_slot`, `still_parked`, `expire_reservations`
- `supabase/verify.sql`: queries to confirm the database matches the app
- `prototype/`: earlier demos (offline demo, Claude-artifact version)

## Setup
1. In Supabase, run `schema.sql`, then `functions.sql` in the SQL Editor (already done for the current project). The cron job needs the `pg_cron` extension enabled.
2. Authentication, Sign In / Providers: make sure **Email** is enabled (anonymous sign-ins are not used). For quick testing turn off "Confirm email"; otherwise set Authentication, URL Configuration, Site URL to the address where the app is served.
3. Serve the folder (for example `python3 -m http.server`) or use GitHub Pages, then open `index.html`.
4. Sign in, then tap "Run connection check" at the bottom of the page; every line should say OK.

## Rules
5-minute "I’m here" hold (`immediate`), 30-minute "Reserve ahead" hold (`advance`), one active slot per driver, still-parked reminder after 30 minutes, automatic release after 60 minutes (cron runs every minute). The Supabase library is pinned to version 2.93.0 in `index.html`.
