-- Run in Supabase SQL Editor (one at a time) to confirm the database matches the app.

-- 1) Expect 5 lots
select name, display_order from public.lots order by display_order;

-- 2) Expect 50 slots in each of the 5 lots (250 total)
select l.name, count(s.id) as slots from public.lots l
left join public.parking_slots s on s.lot_id = l.id group by l.name, l.display_order order by l.display_order;

-- 3) Expect 5 functions: book_slot, confirm_parking, expire_reservations, release_slot, still_parked
select proname, pg_get_function_arguments(oid) from pg_proc
where pronamespace = 'public'::regnamespace
  and proname in ('book_slot','confirm_parking','release_slot','still_parked','expire_reservations');

-- 4) Expect parking_slots in realtime
select tablename from pg_publication_tables where pubname = 'supabase_realtime';

-- 5) Expect the cron job active
select jobname, schedule, active from cron.job where jobname = 'parkey-expire-reservations';

-- 6) Expect rowsecurity = true on all three tables
select tablename, rowsecurity from pg_tables
where schemaname = 'public' and tablename in ('lots','parking_slots','reservations');
