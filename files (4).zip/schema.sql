-- ParKey database (as run in Supabase). Reference copy kept in the repo.
-- Part 1 of 2: tables, security, seed data, realtime. Functions are in functions.sql.

CREATE TABLE public.lots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    display_order INTEGER NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.parking_slots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lot_id UUID NOT NULL REFERENCES public.lots(id) ON DELETE RESTRICT,
    slot_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'free' CHECK (status IN ('free', 'held', 'parked')),
    current_driver_id UUID REFERENCES auth.users(id),
    reservation_type TEXT CHECK (reservation_type IN ('immediate', 'advance')),
    hold_expires_at TIMESTAMPTZ,
    parked_since TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (lot_id, slot_code),
    CHECK (
        (status = 'free' AND current_driver_id IS NULL AND reservation_type IS NULL
            AND hold_expires_at IS NULL AND parked_since IS NULL)
        OR
        (status = 'held' AND current_driver_id IS NOT NULL AND reservation_type IS NOT NULL
            AND hold_expires_at IS NOT NULL AND parked_since IS NULL)
        OR
        (status = 'parked' AND current_driver_id IS NOT NULL AND reservation_type IS NOT NULL
            AND hold_expires_at IS NULL AND parked_since IS NOT NULL)
    )
);

CREATE TABLE public.reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slot_id UUID NOT NULL REFERENCES public.parking_slots(id) ON DELETE RESTRICT,
    driver_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    reservation_type TEXT NOT NULL CHECK (reservation_type IN ('immediate', 'advance')),
    status TEXT NOT NULL DEFAULT 'held' CHECK (status IN ('held', 'parked', 'released', 'expired')),
    reserved_at TIMESTAMPTZ DEFAULT NOW(),
    hold_expires_at TIMESTAMPTZ,
    parked_at TIMESTAMPTZ,
    released_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX one_active_reservation_per_slot
ON public.reservations (slot_id) WHERE status IN ('held', 'parked');

CREATE UNIQUE INDEX one_active_reservation_per_driver
ON public.reservations (driver_id) WHERE status IN ('held', 'parked') AND driver_id IS NOT NULL;

ALTER TABLE public.lots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parking_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;

INSERT INTO public.lots (name, slug, display_order) VALUES
('Centaurus Mall', 'centaurus-mall', 1),
('Giga Mall', 'giga-mall', 2),
('Packages Mall', 'packages-mall', 3),
('Shifa International Hospital', 'shifa-hospital', 4),
('Jinnah Super Market', 'jinnah-super-market', 5)
ON CONFLICT (slug) DO NOTHING;

-- 50 slots per lot: A1..E10
INSERT INTO public.parking_slots (lot_id, slot_code)
SELECT l.id, CHR(65 + r.row_number) || s.slot_number
FROM public.lots l
CROSS JOIN GENERATE_SERIES(0, 4) AS r(row_number)
CROSS JOIN GENERATE_SERIES(1, 10) AS s(slot_number)
ON CONFLICT (lot_id, slot_code) DO NOTHING;

-- Security policies: everyone can read; all writes go through functions.
DROP POLICY IF EXISTS "Anyone can view lots" ON public.lots;
DROP POLICY IF EXISTS "Anyone can view parking slots" ON public.parking_slots;
DROP POLICY IF EXISTS "Drivers can view own reservations" ON public.reservations;

CREATE POLICY "Anyone can view lots" ON public.lots FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can view parking slots" ON public.parking_slots FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Drivers can view own reservations" ON public.reservations FOR SELECT TO authenticated
USING (driver_id = (SELECT auth.uid()));

GRANT SELECT ON public.lots TO anon, authenticated;
GRANT SELECT ON public.parking_slots TO anon, authenticated;
GRANT SELECT ON public.reservations TO authenticated;

-- Live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.parking_slots;

-- Automatic expiry every minute (requires the pg_cron extension)
SELECT cron.schedule('parkey-expire-reservations', '* * * * *', $$SELECT public.expire_reservations();$$);
