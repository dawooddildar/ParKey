-- ParKey schema. Run once in Supabase: SQL Editor -> New query -> paste -> Run.

create table if not exists public.slots (
  lot_id       int  not null check (lot_id between 0 and 99),
  slot_no      int  not null check (slot_no between 0 and 49),
  state        text not null default 'free' check (state in ('free','hold','parked')),
  owner        uuid references auth.users(id) on delete set null,
  kind         text check (kind in ('now','ahead')),
  hold_until   timestamptz,
  parked_since timestamptz,
  primary key (lot_id, slot_no)
);

-- Everyone can read; nobody can write directly. All changes go through the functions below.
alter table public.slots enable row level security;
drop policy if exists "read slots" on public.slots;
create policy "read slots" on public.slots for select using (true);
revoke insert, update, delete on public.slots from anon, authenticated;
grant select on public.slots to anon, authenticated;

-- Reserve a slot. p_kind: 'now' (5 min hold) or 'ahead' (30 min hold). One active slot per user.
create or replace function public.claim_slot(p_lot int, p_slot int, p_kind text)
returns text language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then return 'not_signed_in'; end if;
  if p_kind not in ('now','ahead') or p_lot not between 0 and 99 or p_slot not between 0 and 49 then
    return 'invalid';
  end if;
  perform pg_advisory_xact_lock(hashtext(uid::text));
  if exists (select 1 from slots where owner = uid and (
        (state = 'hold'   and hold_until > now()) or
        (state = 'parked' and parked_since + interval '1 hour' > now()))) then
    return 'already_has_slot';
  end if;
  insert into slots (lot_id, slot_no, state, owner, kind, hold_until, parked_since)
  values (p_lot, p_slot, 'hold', uid, p_kind,
          now() + case when p_kind = 'ahead' then interval '30 minutes' else interval '5 minutes' end, null)
  on conflict (lot_id, slot_no) do update
    set state = 'hold', owner = uid, kind = p_kind,
        hold_until = excluded.hold_until, parked_since = null
    where slots.state = 'free'
       or (slots.state = 'hold'   and slots.hold_until <= now())
       or (slots.state = 'parked' and slots.parked_since + interval '1 hour' <= now());
  if not found then return 'taken'; end if;
  return 'ok';
end $$;

-- Driver confirms they parked (only while the hold is still valid).
create or replace function public.confirm_parked(p_lot int, p_slot int)
returns text language plpgsql security definer set search_path = public as $$
begin
  update slots set state = 'parked', parked_since = now(), hold_until = null
   where lot_id = p_lot and slot_no = p_slot and owner = auth.uid()
     and state = 'hold' and hold_until > now();
  if not found then return 'expired'; end if;
  return 'ok';
end $$;

-- "I'm still here": restarts the 1-hour auto-release clock.
create or replace function public.still_here(p_lot int, p_slot int)
returns text language plpgsql security definer set search_path = public as $$
begin
  update slots set parked_since = now()
   where lot_id = p_lot and slot_no = p_slot and owner = auth.uid()
     and state = 'parked' and parked_since + interval '1 hour' > now();
  if not found then return 'expired'; end if;
  return 'ok';
end $$;

-- Driver leaves (or an expired hold is cleaned up): slot becomes free.
create or replace function public.leave_slot(p_lot int, p_slot int)
returns text language plpgsql security definer set search_path = public as $$
begin
  update slots set state = 'free', owner = null, kind = null, hold_until = null, parked_since = null
   where lot_id = p_lot and slot_no = p_slot and owner = auth.uid();
  return 'ok';
end $$;

revoke execute on function public.claim_slot(int,int,text), public.confirm_parked(int,int),
  public.still_here(int,int), public.leave_slot(int,int) from public, anon;
grant execute on function public.claim_slot(int,int,text), public.confirm_parked(int,int),
  public.still_here(int,int), public.leave_slot(int,int) to authenticated;

-- Live updates to every phone.
alter publication supabase_realtime add table public.slots;
