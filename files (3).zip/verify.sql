-- Run in Supabase SQL Editor (one query at a time) to check the setup matches the app.

-- 1) Columns: expect lot_id, slot_no, state, owner, kind, hold_until, parked_since
select column_name, data_type from information_schema.columns
where table_schema = 'public' and table_name = 'slots' order by ordinal_position;

-- 2) Functions: expect 4 rows: claim_slot, confirm_parked, leave_slot, still_here
select proname, pg_get_function_arguments(oid) from pg_proc
where pronamespace = 'public'::regnamespace
  and proname in ('claim_slot','confirm_parked','still_here','leave_slot');

-- 3) Realtime: expect one row with slots
select tablename from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'slots';

-- 4) Security rules: expect one row "read slots" with cmd SELECT
select policyname, cmd from pg_policies where tablename = 'slots';

-- 5) Row security on: expect true
select relrowsecurity from pg_class where oid = 'public.slots'::regclass;
